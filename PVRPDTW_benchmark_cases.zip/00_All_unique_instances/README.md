# PVRPDTW paper benchmark cases

This package contains all non-real-data benchmark instances named in the Experiments section.

- JSON cases: 54 (45 comparison-grid cases + 9 auxiliary cases)
- Naming rule: `N{customers}W{nominal time-window width}T{planning horizon}`
- `service_days` is intentionally absent. The algorithm must select the specific service days.
- `service_frequency` is retained as the periodic-demand input and is generated deterministically in the range 1–7.
- The source W80 time-window widths are heterogeneous. W120 and W160 are obtained by scaling each source window by 1.5 and 2.0 around its midpoint.
- N100 is constructed from N80 instance 001 plus N20 instance 003; those two files have no overlapping customer coordinates.
- The appendix token `N50W160T121` is treated as a typographical error and is not generated; the repeatedly stated calibration case `N55W160T21` is used.

## Instance names

- `N10W80T7`
- `N15W80T7`
- `N20W80T7`
- `N20W80T14`
- `N20W80T21`
- `N20W120T7`
- `N20W120T14`
- `N20W120T21`
- `N20W160T7`
- `N20W160T14`
- `N20W160T21`
- `N25W80T7`
- `N30W80T7`
- `N35W80T7`
- `N35W120T14`
- `N40W80T7`
- `N40W80T14`
- `N40W80T21`
- `N40W120T7`
- `N40W120T14`
- `N40W120T21`
- `N40W160T7`
- `N40W160T14`
- `N40W160T21`
- `N45W80T7`
- `N50W80T7`
- `N55W160T21`
- `N60W80T7`
- `N60W80T14`
- `N60W80T21`
- `N60W120T7`
- `N60W120T14`
- `N60W120T21`
- `N60W160T7`
- `N60W160T14`
- `N60W160T21`
- `N80W80T7`
- `N80W80T14`
- `N80W80T21`
- `N80W120T7`
- `N80W120T14`
- `N80W120T21`
- `N80W160T7`
- `N80W160T14`
- `N80W160T21`
- `N100W80T7`
- `N100W80T14`
- `N100W80T21`
- `N100W120T7`
- `N100W120T14`
- `N100W120T21`
- `N100W160T7`
- `N100W160T14`
- `N100W160T21`
